import requests

files_to_upload = [
    (
        "sample_evidence.log",
        b"""[2026-09-29 10:13:30 UTC] [BROWSER_DOWNLOAD] Host: WORKSTATION-RIG-01 (192.168.1.105) User: SYSTEM_ADMIN Action: Downloaded stager_update.exe from http://185.220.101.44/payload [MITRE: T1189]
[2026-09-29 10:14:02 UTC] [USB_ATTACHED] Host: WORKSTATION-RIG-01 Device: Kingston DataTraveler 3.0 Serial: AA000000000012948 Mounted: E: [MITRE: T1091]
[2026-09-29 10:14:20 UTC] [FILE_EXFILTRATION] Host: WORKSTATION-RIG-01 Source: C:\\Documents\\confidential_q3.xlsx Dest: E:\\confidential_q3.xlsx Size: 3.8MB [MITRE: T1052.001]
[2026-09-29 10:15:11 UTC] [PROCESS_CREATION] Host: WORKSTATION-RIG-01 Process: powershell.exe Cmd: powershell.exe -nop -w hidden -EncodedCommand aHR0cHM6Ly9tYWxpY2lvdXMtYzIub3JnL2NvbW1hbmQ= [MITRE: T1059.001]
[2026-09-29 10:15:45 UTC] [NETWORK_C2_BEACON] Host: WORKSTATION-RIG-01 Src: 192.168.1.105 Dest: 185.220.101.44 Domain: malicious-c2-beacon.darknet.xyz Protocol: DNS/UDP 53 [MITRE: T1071.004]"""
    ),
    (
        "Security.evtx",
        b"Windows Event Log EVTX binary header mock [EventID 4624 - Logon Type 2: User SYSTEM_ADMIN] [EventID 4688 - Process Creation: powershell.exe hidden EncodedCommand]"
    ),
    (
        "traffic_capture.pcap",
        b"PCAP network packet stream capture: UDP 53 DNS Query -> malicious-c2-beacon.darknet.xyz -> 185.220.101.44"
    ),
    (
        "SYSTEM.hive",
        b"Windows Registry SYSTEM Hive: USBSTOR\\Disk&Ven_Kingston&Prod_DataTraveler_3.0\\AA000000000012948"
    ),
    (
        "History.sqlite",
        b"SQLite format 3: Chrome History URL records -> http://185.220.101.44/payload/stager_update.exe"
    )
]

for fname, content in files_to_upload:
    res = requests.post(
        "https://trace-ai-k62e.onrender.com/api/evidence/upload",
        files={"file": (fname, content)},
        data={"investigator": "Inspector V. Sharma (Lead Cyber Cell)"}
    )
    if res.status_code == 200:
        ev = res.json().get("evidence", {})
        print(f"Uploaded {fname} | ID: {ev.get('evidence_id')} | SHA-256: {ev.get('sha256')[:16]}... | Status: {ev.get('status')}")
    else:
        print(f"Failed {fname}: {res.status_code} {res.text}")
