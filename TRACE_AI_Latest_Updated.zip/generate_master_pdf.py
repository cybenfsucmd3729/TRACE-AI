import os
import sys
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether, HRFlowable
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch

def create_pdf(filename):
    doc = SimpleDocTemplate(
        filename,
        pagesize=letter,
        rightMargin=40,
        leftMargin=40,
        topMargin=40,
        bottomMargin=40
    )
    
    styles = getSampleStyleSheet()
    
    # Custom Palette
    c_primary = colors.HexColor('#0f172a')    # Dark Slate
    c_accent = colors.HexColor('#0284c7')     # Cyan/Blue
    c_purple = colors.HexColor('#7c3aed')     # Purple
    c_dark = colors.HexColor('#334155')       # Text Dark
    c_bg_box = colors.HexColor('#f0f9ff')     # Blue Box BG
    c_bg_speech = colors.HexColor('#f5f3ff')  # Purple Box BG
    
    # Custom Paragraph Styles
    style_title = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=20,
        leading=24,
        textColor=c_primary,
        alignment=1,
        spaceAfter=6
    )
    
    style_subtitle = ParagraphStyle(
        'DocSubTitle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=11,
        leading=14,
        textColor=c_accent,
        alignment=1,
        spaceAfter=15
    )
    
    style_h1 = ParagraphStyle(
        'Heading1_Custom',
        parent=styles['Heading2'],
        fontName='Helvetica-Bold',
        fontSize=14,
        leading=18,
        textColor=c_primary,
        spaceBefore=12,
        spaceAfter=6
    )
    
    style_h2 = ParagraphStyle(
        'Heading2_Custom',
        parent=styles['Heading3'],
        fontName='Helvetica-Bold',
        fontSize=11,
        leading=14,
        textColor=c_accent,
        spaceBefore=8,
        spaceAfter=4
    )
    
    style_body = ParagraphStyle(
        'Body_Custom',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=9.5,
        leading=13.5,
        textColor=c_dark,
        spaceAfter=6
    )
    
    style_code = ParagraphStyle(
        'Code_Custom',
        parent=styles['Normal'],
        fontName='Courier',
        fontSize=8.5,
        leading=11.5,
        textColor=colors.HexColor('#0f172a'),
        backColor=colors.HexColor('#f1f5f9'),
        spaceAfter=6,
        leftIndent=10
    )

    style_speech = ParagraphStyle(
        'Speech_Custom',
        parent=styles['Normal'],
        fontName='Helvetica-Oblique',
        fontSize=9.5,
        leading=13.5,
        textColor=colors.HexColor('#4c1d95'),
        spaceAfter=6
    )

    story = []

    # Title & Header
    story.append(Paragraph("🏛️ TRACE-AI: Complete Technical Dossier & Master Blueprint", style_title))
    story.append(Paragraph("AI-Powered Digital Evidence Correlation & Legal Admissibility Framework (SUTRAM 2026 Edition)", style_subtitle))
    story.append(HRFlowable(width="100%", thickness=1.5, color=c_accent, spaceBefore=0, spaceAfter=12))

    # Executive Overview Box
    overview_text = (
        "<b>Executive Summary & Value Proposition:</b><br/>"
        "TRACE-AI is an end-to-end cyber investigation framework built for the <b>SUTRAM 2026 National Level Cyber Hackathon</b> "
        "(organized by IGDTUW under MeitY ISEA Phase-III). TRACE-AI solves the 3 biggest bottlenecks in digital forensics: "
        "<br/>1. <b>Siloed Log Avalanche:</b> Correlates EVTX, PCAP, USB, SQLite, and Syslog artifacts into one microsecond UTC super timeline."
        "<br/>2. <b>Zero-Hallucination AI Copilot:</b> Grounded strictly in verified event logs with exact citations [Log: EVT_002 @ 10:14:02 UTC]."
        "<br/>3. <b>1-Click Legal Admissibility:</b> Generates court-certified Electronic Evidence Certificates under <b>Bharatiya Sakshya Adhiniyam, 2023 (BSA Section 63 / Evidence Act Section 65B)</b>."
    )
    
    t_box = Table([[Paragraph(overview_text, style_body)]], colWidths=[530])
    t_box.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), c_bg_box),
        ('BOX', (0,0), (-1,-1), 1, c_accent),
        ('PADDING', (0,0), (-1,-1), 8),
    ]))
    story.append(t_box)
    story.append(Spacer(1, 10))

    # Section 1: Problem Statement
    story.append(Paragraph("1. The Forensic Dilemma (Problem Statement)", style_h1))
    story.append(Paragraph(
        "Modern cyber crime leaves digital evidence scattered across hundreds of thousands of isolated log lines. "
        "Human investigators spend weeks manually aligning mismatched timestamps across files (Windows Security EVTX, PCAP packet captures, "
        "USB Registry hives, and Chrome History SQLite databases) to reconstruct just 1 hour of an attack. Furthermore, generic public AI (ChatGPT) "
        "hallucinates timestamps and IP addresses, rendering findings legally inadmissible under Indian evidence laws.",
        style_body
    ))

    # Section 2: Architecture
    story.append(Paragraph("2. System Architecture & 4-Step Forensic Pipeline", style_h1))
    pipeline_data = [
        ["Pipeline Step", "Core Engine Module", "Technical Function & Legal Compliance"],
        ["Step 1: Intake & Lock", "forensic_engine/ingestion.py", "Instant SHA-256 / SHA-3 hashing, ISO 27037 write-blocked sandbox & Chain of Custody ledger."],
        ["Step 2: Normalization", "forensic_engine/parsers.py", "Parses EVTX, PCAP, USB Reg, SQLite, Syslog into Plaso-style microsecond UTC timeline."],
        ["Step 3: Graph & MITRE", "forensic_engine/graph_engine.py", "Causal Knowledge Graph linking User ↔ Process ↔ IP ↔ USB. Automatic MITRE ATT&CK mapping."],
        ["Step 4: AI & BSA Legal", "ai_copilot/grounded_rag.py", "Zero-hallucination Grounded AI Copilot with log citations & BSA 2023 / Sec 65B court certificate export."]
    ]
    t_pipeline = Table(pipeline_data, colWidths=[110, 150, 270])
    t_pipeline.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), c_accent),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0), (-1,0), 9),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#cbd5e1')),
        ('PADDING', (0,0), (-1,-1), 5),
    ]))
    story.append(t_pipeline)
    story.append(Spacer(1, 10))

    # Section 3: Grounded AI Copilot
    story.append(Paragraph("3. Is TRACE-AI a Fully Functional AI?", style_h1))
    story.append(Paragraph(
        "<b>YES. TRACE-AI is a fully functional, hybrid AI system.</b> It integrates Google's <b>Gemini API</b> (google-genai SDK) "
        "coupled with a <b>Grounded RAG (Retrieval-Augmented Generation) Architecture</b>. "
        "Unlike public AI that invents data, TRACE-AI queries an immutable forensic event graph and returns exact evidence citations "
        "for every claim. If internet access is unavailable in remote police stations, it seamlessly falls back to an offline deterministic forensic RAG engine.",
        style_body
    ))

    # Section 4: Real World Applications
    story.append(Paragraph("4. Where TRACE-AI is Used & Real-World Impact", style_h1))
    story.append(Paragraph(
        "• <b>State Cyber Crime Cells & Police Stations:</b> Empowers police investigating officers (IOs) to analyze seized laptops/USB drives in minutes.<br/>"
        "• <b>CBI / CERT-In / National Agencies:</b> For insider threat tracking, espionage, and corporate data theft investigations.<br/>"
        "• <b>Corporate SOC Teams:</b> Investigating ransomware staging, employee data theft, and unauthorized privilege escalation.<br/>"
        "• <b>Indian Courts of Law:</b> Generating certified electronic evidence under Section 63 of Bharatiya Sakshya Adhiniyam 2023.",
        style_body
    ))

    # Section 5: Security & Privacy
    story.append(Paragraph("5. Security, Data Privacy & Access Control", style_h1))
    story.append(Paragraph(
        "When published publicly or deployed to cloud/police servers, TRACE-AI maintains 4 strict security barriers:<br/>"
        "1. <b>Role-Based Access Control (RBAC):</b> JWT-authenticated access for Officers, Analysts, and Legal Counsel.<br/>"
        "2. <b>Case-Level Encryption:</b> Evidence files are encrypted at rest using <b>AES-256</b> and isolated by Case ID.<br/>"
        "3. <b>Data Sovereignty & Zero Leak:</b> Evidence logs NEVER leave the secure sandbox or get shared with public AI models.<br/>"
        "4. <b>Audit Ledger:</b> Every single query, view, or export is cryptographically logged in the Chain of Custody record.",
        style_body
    ))

    story.append(PageBreak())

    # Section 6: Evidence Breakdown
    story.append(Paragraph("6. Evidence Output Breakdown (Line-by-Line Meaning)", style_h1))
    story.append(Paragraph("When an evidence file (e.g. sample_evidence.log) is ingested, TRACE-AI outputs the following response:", style_body))
    
    json_sample = (
        '{\n'
        '  "status": "SUCCESS",\n'
        '  "evidence": {\n'
        '    "evidence_id": "EVD-A1D30B6E",\n'
        '    "filename": "sample_evidence.log",\n'
        '    "file_size_bytes": 578,\n'
        '    "sha256": "48a081076aec6a3004ccd2101831265538692251fe7904e695d89e7ebd1fadd0",\n'
        '    "status": "CRYPTOGRAPHICALLY_LOCKED",\n'
        '    "integrity_verification": "PASSED (ISO 27037 Certified)"\n'
        '  }\n'
        '}'
    )
    story.append(Paragraph(json_sample.replace('\n', '<br/>').replace(' ', '&nbsp;'), style_code))

    exp_data = [
        ["Field Key", "Line-by-Line Technical & Legal Meaning"],
        ["status: SUCCESS", "Artifact accepted into write-blocked sandbox without error."],
        ["evidence_id", "Unique case artifact tracking ID assigned for police records."],
        ["sha256", "SHA-256 Cryptographic Hash Fingerprint. Mathematical proof that zero bitstream tampering occurred."],
        ["status: LOCKED", "File stored in read-only immutable storage conforming to ISO 27037 preservation standards."],
        ["integrity_verification", "Certified audit status confirming digital evidence integrity for court submission."]
    ]
    t_exp = Table(exp_data, colWidths=[140, 390])
    t_exp.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#3b82f6')),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#cbd5e1')),
        ('PADDING', (0,0), (-1,-1), 5),
    ]))
    story.append(t_exp)
    story.append(Spacer(1, 10))

    # Section 7: Presentation Speech
    story.append(Paragraph("7. Complete Presentation Speech Script for Judges", style_h1))
    
    speech_1 = (
        "<b>Introduction (30s):</b><br/>"
        "<i>'Respected Judges, welcome to TRACE-AI. In cyber investigations today, evidence sits trapped across siloed formats—Windows EVTX logs, network PCAPs, and USB registry hives. Connecting these fragmented traces to prove WHO stole WHAT data takes weeks of manual work. TRACE-AI is our answer to MeitY's Secure Bharat mission—an intelligent framework that turns fragmented logs into a court-admissible narrative in seconds.'</i>"
    )
    t_s1 = Table([[Paragraph(speech_1, style_speech)]], colWidths=[530])
    t_s1.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), c_bg_speech),
        ('BOX', (0,0), (-1,-1), 1, c_purple),
        ('PADDING', (0,0), (-1,-1), 6),
    ]))
    story.append(t_s1)
    story.append(Spacer(1, 6))

    speech_2 = (
        "<b>Ingestion & Grounded Copilot (45s):</b><br/>"
        "<i>'TRACE-AI enforces ISO 27037 standards with instant SHA-256 cryptographic locking. Our Correlation Engine builds a Causal Knowledge Graph linking Users to spawned PowerShell commands, USB serials, and C2 beacons. Unlike public AI that hallucinates, our Grounded AI Copilot answers questions with exact log citations like [Log: EVT-002 @ 10:14:02 UTC].'</i>"
    )
    t_s2 = Table([[Paragraph(speech_2, style_speech)]], colWidths=[530])
    t_s2.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), c_bg_speech),
        ('BOX', (0,0), (-1,-1), 1, c_purple),
        ('PADDING', (0,0), (-1,-1), 6),
    ]))
    story.append(t_s2)
    story.append(Spacer(1, 6))

    speech_3 = (
        "<b>Bharatiya Sakshya Adhiniyam 2023 (Sec 65B) Legal Certificate (30s):</b><br/>"
        "<i>'Finally, under Section 63 of Bharatiya Sakshya Adhiniyam 2023 (formerly Sec 65B), TRACE-AI exports a 1-click Electronic Evidence Certificate complete with master case hashes and Ed25519 legal seals—ready for submission in Indian courts of law.'</i>"
    )
    t_s3 = Table([[Paragraph(speech_3, style_speech)]], colWidths=[530])
    t_s3.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), c_bg_speech),
        ('BOX', (0,0), (-1,-1), 1, c_purple),
        ('PADDING', (0,0), (-1,-1), 6),
    ]))
    story.append(t_s3)
    story.append(Spacer(1, 10))

    # Section 8: Cloud Deployment
    story.append(Paragraph("8. Cloud Publishing & Deployment Guide", style_h1))
    story.append(Paragraph(
        "• <b>Localtunnel (Instant Public Demo Link):</b> Run <code>npx localtunnel --port 8000</code> in PowerShell for an instant live URL.<br/>"
        "• <b>Render / Railway (Free 24/7 Hosting):</b> Push code to GitHub and connect repository to Render. Build command: <code>pip install -r requirements.txt</code>. Start command: <code>uvicorn main:app --host 0.0.0.0 --port $PORT</code>.<br/>"
        "• <b>Docker Container:</b> Includes Dockerfile for GCP Cloud Run or AWS ECS container deployment.",
        style_body
    ))

    # Build Document
    doc.build(story)
    print(f"PDF successfully generated at: {filename}")

if __name__ == '__main__':
    target = os.path.join(os.path.dirname(__file__), "TRACE_AI_Complete_Master_Blueprint.pdf")
    create_pdf(target)
