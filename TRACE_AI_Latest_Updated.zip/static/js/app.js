window.switchTab = function(targetId) {
    const tabBtns = document.querySelectorAll(".nav-tabs .tab-btn");
    const tabPanels = document.querySelectorAll(".tab-panel");

    tabBtns.forEach(b => {
        if (b.getAttribute("data-tab") === targetId) {
            b.classList.add("active");
        } else {
            b.classList.remove("active");
        }
    });

    tabPanels.forEach(p => {
        if (p.id === targetId) {
            p.classList.add("active");
        } else {
            p.classList.remove("active");
        }
    });

    if (targetId === "tab-graph" && typeof renderCausalGraph === "function") {
        renderCausalGraph();
    }
    if (targetId === "tab-ingest" && typeof renderEvidenceFiles === "function") {
        renderEvidenceFiles();
    }
};

document.addEventListener("DOMContentLoaded", () => {
    initTabs();
    loadDemoScenario();
    setupUploader();
});

function initTabs() {
    const tabBtns = document.querySelectorAll(".nav-tabs .tab-btn");
    tabBtns.forEach(btn => {
        btn.addEventListener("click", (e) => {
            e.preventDefault();
            const target = btn.getAttribute("data-tab");
            if (target) {
                window.switchTab(target);
            }
        });
    });
}


async function loadDemoScenario() {
    try {
        const res = await fetch("/api/forensics/demo-scenario");
        const data = await res.json();
        
        if (data.status === "SUCCESS") {
            window.traceAiState = data;
            renderOverview(data.summary);
            renderTimeline(data.scenario.events);
            renderMitreMatrix(data.mitre_matrix);
            renderChainOfCustody();
            renderEvidenceFiles();
        }
    } catch (err) {
        console.error("Failed to load demo scenario:", err);
    }
}

function renderOverview(summary) {
    const titleEl = document.getElementById("incident-title");
    if (titleEl && summary) titleEl.innerText = summary.incident_name;
    const eventsEl = document.getElementById("metric-events");
    if (eventsEl && summary) eventsEl.innerText = summary.total_correlated_events;
    const threatEl = document.getElementById("metric-threat");
    if (threatEl && summary) threatEl.innerText = summary.overall_threat_level;
    const hostEl = document.getElementById("metric-host");
    if (hostEl && summary) hostEl.innerText = summary.affected_host;
    
    const tacticsContainer = document.getElementById("summary-tactics");
    if (tacticsContainer && summary && summary.mitre_tactics_triggered) {
        tacticsContainer.innerHTML = summary.mitre_tactics_triggered.map(t => 
            `<span class="status-badge" style="background:rgba(239, 68, 68, 0.2); color:#ef4444; border-color:rgba(239, 68, 68, 0.4)">${t}</span>`
        ).join(" ");
    }
}

function setupUploader() {
    const fileInput = document.getElementById("evidence-file-input");
    const uploadBtn = document.getElementById("btn-upload");
    const display = document.getElementById("selected-file-display");
    const dropZone = document.getElementById("upload-zone-area");
    const sampleBtn = document.getElementById("btn-quick-sample");

    if (dropZone && fileInput) {
        // Drag and drop handlers
        ['dragenter', 'dragover'].forEach(eventName => {
            dropZone.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
                dropZone.style.borderColor = "var(--accent-cyan)";
                dropZone.style.background = "rgba(56, 189, 248, 0.1)";
            }, false);
        });

        ['dragleave', 'drop'].forEach(eventName => {
            dropZone.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
                dropZone.style.borderColor = "rgba(56, 189, 248, 0.3)";
                dropZone.style.background = "rgba(13, 17, 26, 0.6)";
            }, false);
        });

        dropZone.addEventListener('drop', (e) => {
            const dt = e.dataTransfer;
            const files = dt.files;
            if (files && files.length) {
                fileInput.files = files;
                const file = files[0];
                if (display) {
                    display.innerText = `📄 Selected File: ${file.name} (${(file.size / 1024).toFixed(1)} KB)`;
                }
            }
        });
    }

    if (fileInput) {
        fileInput.addEventListener("change", () => {
            if (fileInput.files && fileInput.files[0]) {
                const file = fileInput.files[0];
                if (display) {
                    display.innerText = `📄 Selected File: ${file.name} (${(file.size / 1024).toFixed(1)} KB)`;
                }
            }
        });
    }

    if (uploadBtn && fileInput) {
        uploadBtn.addEventListener("click", async () => {
            if (!fileInput.files || !fileInput.files.length) {
                alert("Please click 'Browse Evidence File' or drag a file to select an artifact first.");
                return;
            }

            const formData = new FormData();
            formData.append("file", fileInput.files[0]);
            formData.append("investigator", "Inspector V. Sharma (Lead Cyber Cell)");

            uploadBtn.innerText = "Ingesting & Locking SHA-256...";
            uploadBtn.disabled = true;

            try {
                const res = await fetch("/api/evidence/upload", {
                    method: "POST",
                    body: formData
                });
                const result = await res.json();

                if (result.status === "SUCCESS") {
                    alert(`✔ Artifact Ingested & Cryptographically Locked!\nFile: ${result.evidence.filename}\nSHA-256: ${result.evidence.sha256}`);
                    if (display) display.innerText = `✔ Ingested & Locked: ${result.evidence.filename}`;
                    fileInput.value = "";
                    await loadDemoScenario();
                    await renderEvidenceFiles();
                    await renderChainOfCustody();
                } else {
                    alert("Ingestion error: " + (result.detail || "Unknown error"));
                }
            } catch (e) {
                alert("Failed to upload evidence: " + e.message);
            } finally {
                uploadBtn.innerText = "Upload & Cryptographic Lock";
                uploadBtn.disabled = false;
            }
        });
    }

    if (sampleBtn) {
        sampleBtn.addEventListener("click", async () => {
            sampleBtn.innerText = "Ingesting Sample Artifact...";
            sampleBtn.disabled = true;
            try {
                const blob = new Blob([
                    "[2026-09-29 10:14:02 UTC] [USBSTOR] Vendor: Kingston Model: DataTraveler_3.0 Serial: AA000000000012948"
                ], { type: "text/plain" });
                const testFile = new File([blob], "incident_evidence_dump.log", { type: "text/plain" });
                
                const formData = new FormData();
                formData.append("file", testFile);
                formData.append("investigator", "Inspector V. Sharma (Lead Cyber Cell)");

                const res = await fetch("/api/evidence/upload", {
                    method: "POST",
                    body: formData
                });
                const result = await res.json();
                if (result.status === "SUCCESS") {
                    alert(`✔ Sample Ingested & Locked!\nID: ${result.evidence.evidence_id}\nSHA-256: ${result.evidence.sha256}`);
                    await loadDemoScenario();
                    await renderEvidenceFiles();
                    await renderChainOfCustody();
                }
            } catch (err) {
                alert("Failed to ingest sample: " + err.message);
            } finally {
                sampleBtn.innerText = "⚡ Ingest Sample Evidence Log (1-Click)";
                sampleBtn.disabled = false;
            }
        });
    }

    renderEvidenceFiles();
}


async function renderEvidenceFiles() {
    const container = document.getElementById("ingested-files-container");
    if (!container) return;

    let files = [];
    try {
        const res = await fetch("/api/evidence/list");
        const data = await res.json();
        if (data.files) files = data.files;
    } catch(e) {}

    // Default preloaded evidence files if none uploaded yet
    if (!files.length) {
        files = [
            {
                evidence_id: "EVD-A912F4",
                filename: "Security.evtx",
                file_size_bytes: 4194304,
                sha256: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                ingested_by: "Inspector V. Sharma",
                ingested_at_utc: "2026-09-29T10:13:30Z",
                status: "CRYPTOGRAPHICALLY_LOCKED"
            },
            {
                evidence_id: "EVD-B771E2",
                filename: "SYSTEM.hive",
                file_size_bytes: 2097152,
                sha256: "8f434346648f6b96df89dda901c5176b10a6d83961dd3c1ac88b59b2dc327aa4",
                ingested_by: "Inspector V. Sharma",
                ingested_at_utc: "2026-09-29T10:14:02Z",
                status: "CRYPTOGRAPHICALLY_LOCKED"
            },
            {
                evidence_id: "EVD-C882D1",
                filename: "traffic_capture.pcap",
                file_size_bytes: 14680064,
                sha256: "131b79f6486f0d7e6e5a409f583f707f1523497d3f18a666e3b0c44298fc1c14",
                ingested_by: "Inspector V. Sharma",
                ingested_at_utc: "2026-09-29T10:15:45Z",
                status: "CRYPTOGRAPHICALLY_LOCKED"
            },
            {
                evidence_id: "EVD-D993C0",
                filename: "History.sqlite",
                file_size_bytes: 524288,
                sha256: "7d0d0f2b3e8c9a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b",
                ingested_by: "Inspector V. Sharma",
                ingested_at_utc: "2026-09-29T10:13:30Z",
                status: "CRYPTOGRAPHICALLY_LOCKED"
            },
            {
                evidence_id: "EVD-E004B9",
                filename: "sample_evidence.log",
                file_size_bytes: 578,
                sha256: "48a081076aec6a3004ccd2101831265538692251fe7904e695d89e7ebd1fadd0",
                ingested_by: "Inspector V. Sharma",
                ingested_at_utc: "2026-09-30T10:14:00Z",
                status: "CRYPTOGRAPHICALLY_LOCKED"
            }
        ];
    }

    container.innerHTML = `
        <table class="cert-table" style="margin:0; background:rgba(13,17,26,0.9); border-radius:8px; overflow:hidden;">
            <thead>
                <tr style="background:rgba(56,189,248,0.1); color:#38bdf8;">
                    <th>Evidence ID</th>
                    <th>File Name</th>
                    <th>Size</th>
                    <th>SHA-256 Hash</th>
                    <th>Ingested By</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                ${files.map(f => `
                    <tr style="color:#f8fafc; border-bottom:1px solid rgba(255,255,255,0.05);">
                        <td><strong style="color:#a855f7;">${f.evidence_id}</strong></td>
                        <td>📄 ${f.filename}</td>
                        <td>${(f.file_size_bytes / 1024).toFixed(1)} KB</td>
                        <td style="font-family:'Fira Code'; font-size:0.75rem; color:#38bdf8;">${f.sha256.substring(0,24)}...</td>
                        <td>${f.ingested_by || 'Officer Admin'}</td>
                        <td><span class="status-badge" style="background:rgba(16,185,129,0.2); color:#10b981; font-size:0.75rem;">${f.status}</span></td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

async function renderChainOfCustody() {
    try {
        const res = await fetch("/api/evidence/chain-of-custody");
        const data = await res.json();
        const container = document.getElementById("coc-ledger-list");
        if (container && data.chain_of_custody) {
            container.innerHTML = data.chain_of_custody.map(item => `
                <div class="timeline-item">
                    <div class="timeline-timestamp">${item.timestamp_utc.split('T')[1].replace('Z','')}</div>
                    <div class="timeline-content">
                        <div class="timeline-title">${item.action} — ${item.filename}</div>
                        <div class="timeline-desc">Actor: ${item.actor} | SHA-256: ${item.evidence_sha256.substring(0, 16)}...</div>
                    </div>
                    <div style="font-family:'Fira Code'; font-size:0.75rem; color:#10b981;">VERIFIED CoC #${item.entry_index}</div>
                </div>
            `).join("");
        }
    } catch(e) {}
}
