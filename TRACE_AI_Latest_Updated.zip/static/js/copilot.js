/**
 * Grounded AI Copilot Chat Interface
 */

document.addEventListener("DOMContentLoaded", () => {
    const sendBtn = document.getElementById("btn-send-chat");
    const input = document.getElementById("chat-input");

    if (sendBtn && input) {
        sendBtn.addEventListener("click", () => handleSendQuery());
        input.addEventListener("keypress", (e) => {
            if (e.key === "Enter") handleSendQuery();
        });
    }

    // Quick prompt pill triggers
    const pills = document.querySelectorAll(".prompt-pill");
    pills.forEach(p => {
        p.addEventListener("click", () => {
            if (input) {
                input.value = p.innerText;
                handleSendQuery();
            }
        });
    });
});

async function handleSendQuery() {
    const input = document.getElementById("chat-input");
    const msgBox = document.getElementById("chat-messages");
    if (!input || !msgBox) return;

    const query = input.value.trim();
    if (!query) return;

    // Append User Message
    msgBox.innerHTML += `
        <div class="msg msg-user">
            <div>${escapeHtml(query)}</div>
        </div>
    `;
    input.value = "";
    msgBox.scrollTop = msgBox.scrollHeight;

    // Append Loading Copilot Message
    const loadingId = "load-" + Date.now();
    msgBox.innerHTML += `
        <div class="msg msg-copilot" id="${loadingId}">
            <div style="display:flex; align-items:center; gap:8px;">
                <span style="animation:spin 1s infinite linear;">⚡</span> Grounding query against verified log timestamps...
            </div>
        </div>
    `;
    msgBox.scrollTop = msgBox.scrollHeight;

    try {
        const res = await fetch("/api/copilot/query", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ query: query })
        });
        const data = await res.json();

        const loadingElem = document.getElementById(loadingId);
        if (loadingElem) {
            let citationsHtml = "";
            if (data.citations && data.citations.length) {
                citationsHtml = `<div style="margin-top:10px; padding-top:8px; border-top:1px solid rgba(255,255,255,0.1);">
                    <div style="font-size:0.75rem; color:#94a3b8; font-weight:700;">STRICT EVIDENCE CITATIONS:</div>
                    ${data.citations.map(c => `<span class="citation-tag">${c}</span>`).join(" ")}
                </div>`;
            }

            loadingElem.innerHTML = `
                <div>
                    <div style="font-weight:700; color:#38bdf8; font-size:0.8rem; margin-bottom:4px; display:flex; justify-content:space-between;">
                        <span>TRACE-AI GROUNDED COPILOT</span>
                        <span style="color:#10b981;">${data.confidence_level || 'VERIFIED'}</span>
                    </div>
                    <div>${formatMarkdown(data.answer)}</div>
                    ${citationsHtml}
                </div>
            `;
            msgBox.scrollTop = msgBox.scrollHeight;
        }
    } catch (e) {
        const loadingElem = document.getElementById(loadingId);
        if (loadingElem) {
            loadingElem.innerHTML = `<div style="color:#ef4444;">Error connecting to Copilot engine.</div>`;
        }
    }
}

function escapeHtml(text) {
    return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function formatMarkdown(text) {
    return text
        .replace(/\n\n/g, "<br/><br/>")
        .replace(/\n/g, "<br/>")
        .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
        .replace(/### (.*?)(<br\/>|$)/g, "<h4 style='color:#38bdf8; margin:8px 0;'>$1</h4>");
}
