/**
 * Vis.js Dynamic Causal Network Graph Visualizer
 */

let visNetwork = null;

async function renderCausalGraph() {
    const container = document.getElementById("vis-graph-container");
    if (!container) return;

    try {
        const res = await fetch("/api/forensics/graph");
        const graphData = await res.json();

        const data = {
            nodes: new vis.DataSet(graphData.nodes),
            edges: new vis.DataSet(graphData.edges)
        };

        const options = {
            nodes: {
                borderWidth: 2,
                font: { color: "#ffffff", face: "Inter", size: 12 },
                shadow: true
            },
            edges: {
                width: 2,
                smooth: { type: "continuous" }
            },
            physics: {
                stabilization: true,
                barnesHut: {
                    gravitationalConstant: -3000,
                    springLength: 120
                }
            },
            interaction: {
                hover: true,
                tooltipDelay: 100
            }
        };

        if (visNetwork) {
            visNetwork.destroy();
        }

        visNetwork = new vis.Network(container, data, options);
    } catch (e) {
        console.error("Failed to render graph:", e);
    }
}
