/**
 * Swimlane Timeline Visualizer
 */

function renderTimeline(events) {
    const container = document.getElementById("timeline-list");
    if (!container) return;

    container.innerHTML = events.map(ev => {
        const timeStr = ev.timestamp_utc ? ev.timestamp_utc.replace("T", " ").replace("Z", " UTC") : "N/A";
        const riskClass = (ev.risk_score || "LOW").toLowerCase();
        
        return `
            <div class="timeline-item ${riskClass}">
                <div class="timeline-timestamp">${timeStr}</div>
                <div class="timeline-content">
                    <div class="timeline-title">${ev.category} — ${ev.source}</div>
                    <div class="timeline-desc">${ev.description}</div>
                    <div style="margin-top:4px;">
                        <span class="citation-tag">${ev.event_id}</span>
                        <span class="citation-tag" style="background:rgba(168, 85, 247, 0.15); color:#a855f7;">${ev.mitre_id || "MITRE"}</span>
                        <span style="font-size:0.75rem; color:#94a3b8; margin-left:8px;">Artifact: ${ev.artifact}</span>
                    </div>
                </div>
                <div style="text-align:right;">
                    <span class="status-badge" style="background:${riskClass === 'critical' ? 'rgba(239, 68, 68, 0.2)' : 'rgba(245, 158, 11, 0.2)'}; color:${riskClass === 'critical' ? '#ef4444' : '#f59e0b'};">
                        ${ev.risk_score || 'MEDIUM'}
                    </span>
                </div>
            </div>
        `;
    }).join("");
}

function renderMitreMatrix(matrix) {
    const container = document.getElementById("mitre-matrix-grid");
    if (!container) return;

    let html = "";
    for (const [tactic, evList] of Object.entries(matrix)) {
        html += `
            <div class="card" style="padding:1rem;">
                <div class="card-header" style="margin-bottom:0.5rem; padding-bottom:0.4rem;">
                    <div class="card-title" style="font-size:0.95rem;">${tactic} (${evList.length})</div>
                </div>
                <div style="display:flex; flex-direction:column; gap:6px;">
                    ${evList.length === 0 ? '<div style="font-size:0.8rem; color:#64748b;">No detected events</div>' : 
                      evList.map(ev => `
                        <div style="background:rgba(13, 17, 26, 0.8); padding:6px 10px; border-radius:4px; font-size:0.8rem; border-left:3px solid #ef4444;">
                            <div style="font-weight:600; color:#38bdf8;">${ev.mitre_id}: ${ev.category}</div>
                            <div style="color:#94a3b8; font-size:0.75rem;">${ev.event_id} @ ${ev.timestamp_utc.split('T')[1]}</div>
                        </div>
                      `).join("")}
                </div>
            </div>
        `;
    }
    container.innerHTML = html;
}
