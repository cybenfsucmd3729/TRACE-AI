# TRACE-AI — Digital Evidence Correlation & Forensic Investigation Framework
Developed for **SUTRAM 2026 National Level Cyber Hackathon**
Organized by **IGDTUW** under **ISEA Project Phase-III, MeitY, Govt. of India**.

---

## 🌟 Overview
TRACE-AI ingests multi-source digital evidence (EVTX, PCAP, USB Registry, Browser SQLite, Syslog), guarantees cryptographic integrity (SHA-256 / SHA-3), correlates events into a microsecond UTC-aligned causal graph, and generates court-admissible electronic evidence certificates under **Bharatiya Sakshya Adhiniyam 2023 (BSA Section 63 / Evidence Act Section 65B)**.

---

## 🚀 Quick Local Start

```bash
# 1. Navigate to project
cd trace-ai-sutram2026

# 2. Install dependencies
pip install -r requirements.txt

# 3. Start server
python -m uvicorn main:app --host 127.0.0.1 --port 8000 --reload
```

Open browser at: **http://127.0.0.1:8000**

---

## 🌐 How to Publish Live Online

### Method 1: Instant Public Link (localtunnel / ngrok)
Run this command in PowerShell to get an instant public URL to send to hackathon judges:
```bash
npx localtunnel --port 8000
```

### Method 2: Deploy to Render / Railway / Cloud Run
1. Push code to a GitHub repository:
   ```bash
   git init
   git add .
   git commit -m "Initial commit for TRACE-AI SUTRAM 2026"
   git remote add origin <your-github-repo-url>
   git push -u origin main
   ```
2. Log into [Render.com](https://render.com) or [Railway.app](https://railway.app).
3. Select "New Web Service" -> Connect GitHub repo.
4. Set Build Command: `pip install -r requirements.txt`
5. Set Start Command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
