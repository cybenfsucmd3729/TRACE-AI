# 🏛️ TRACE-AI: Executive Presentation Guide & Hackathon Pitch
**Framework Title**: TRACE-AI — AI-Powered Digital Evidence Correlation & Forensic Investigation Framework  
**Tagline**: *"Where Every Trace Connects — From Fragmented Logs to Court-Admissible Narrative"*  
**Hackathon Context**: SUTRAM 2026 National Level Cyber Hackathon  
**Organized By**: Indira Gandhi Delhi Technical University for Women (IGDTUW) under ISEA Project Phase-III, MeitY, Govt. of India  

---

> [!IMPORTANT]
> **Key Value Proposition for Judges**: TRACE-AI solves the 3 biggest bottlenecks in Indian cyber forensics:
> 1. **Data Avalanche & Siloed Formats**: Automatically correlates disparate EVTX, PCAP, USB, SQLite, and Syslog artifacts into one unified UTC timeline.
> 2. **Zero-Hallucination AI Copilot**: Grounded strictly in verified log timestamps with exact citations `[Log: EVT_002 @ 10:14:02 UTC]`.
> 3. **1-Click Legal Admissibility**: Generates official court-certified Electronic Evidence Certificates compliant with **Bharatiya Sakshya Adhiniyam, 2023 (BSA Section 63 / Evidence Act Section 65B)**.

---

## 🎯 1. The Problem Statement (The Forensic Dilemma)

Modern cyber crime leaves digital evidence scattered across hundreds of thousands of isolated log lines:
- **Windows EVTX Security Logs**: Logon attempts, process creations.
- **Network PCAP Packet Captures**: Outbound C2 beacons, DNS queries.
- **USB Registry & Shellbags**: Removable device insertions, stolen document copies.
- **Browser SQLite Databases**: Malware stager downloads.

### Why Human Investigators & Generic AI Fail:
- ⏳ **Manual Alignment takes weeks**: Investigators manually align mismatched clock drifts across log files to reconstruct 1 hour of an attack.
- 🚨 **Generic LLMs Hallucinate**: Standard AI (ChatGPT) invents non-existent IP addresses and timestamps—rendering evidence mathematically inadmissible in court.
- ⚖️ **Legal Challenge in Court**: Without cryptographic hashing (SHA-256) and an unbroken Chain of Custody (CoC), defense lawyers easily challenge evidence under **Bharatiya Sakshya Adhiniyam (BSA 2023)**.

---

## 🏗️ 2. The TRACE-AI System Architecture

Below is the end-to-end 4-step forensic pipeline implemented in TRACE-AI:

```mermaid
flowchart TD
    A["📁 Step 1: Multi-Source Evidence Intake\n(EVTX, PCAP, USB Reg, SQLite, Syslog)"] --> B["🔒 Cryptographic Evidence Lock\n(SHA-256 / SHA-3 Hashes & ISO 27037 CoC Ledger)"]
    B --> C["⏳ Step 2: Forensic Normalization Engine\n(Plaso-Style Super Timeline & Microsecond UTC Sync)"]
    C --> D["🧠 Step 3: Correlation & Causal Graph Engine\n(Entity Resolution: User ↔ Process ↔ IP ↔ USB)"]
    D --> E["🎯 MITRE ATT&CK Adversary Tactics Mapper\n(Initial Access, Execution, Exfiltration, C2)"]
    E --> F["🤖 Grounded AI Copilot\n(Zero-Hallucination Answers with Log Citations)"]
    F --> G["📜 Step 4: Legal Admissibility Engine\n(BSA 2023 / Sec 65B Certificate Export)"]
```

---

## 🎤 3. Presentation Pitch Script for Judges (Line-by-Line Speech)

Use this exact script when presenting TRACE-AI to hackathon evaluators:

### 📢 Introduction (30 Seconds):
> *"Respected Judges, welcome to TRACE-AI. In cyber investigations today, police officers and forensic analysts are drowning in a data avalanche. When a host is compromised, evidence sits trapped in siloed formats—Windows EVTX logs, network PCAPs, and USB registry hives. Connecting these fragmented traces to prove WHO stole WHAT data takes weeks of manual work. TRACE-AI is our answer to MeitY's 'Secure Bharat' mission—an intelligent, end-to-end framework that turns fragmented logs into a court-admissible narrative in seconds."*

### 🔒 Step 1: Ingestion & Legal Lock (30 Seconds):
> *"First, TRACE-AI enforces ISO 27037 digital evidence preservation standards. The moment an investigator ingests a log artifact, TRACE-AI computes instant SHA-256 and SHA-3 cryptographic fingerprints and records a tamper-evident Chain of Custody ledger. Zero modification of original bitstream evidence is guaranteed."*

### 🧠 Step 2 & 3: Correlation & Causal Graph (45 Seconds):
> *"Second, TRACE-AI's Correlation Engine synchronizes microsecond UTC timestamps across clock-drifted logs. Our Knowledge Graph Engine resolves entities—connecting User Accounts to spawned PowerShell processes, mounted USB serial numbers, and external C2 IP addresses. It automatically maps the incident to MITRE ATT&CK tactics, showing exact attacker movement."*

### 🤖 Step 3: Grounded AI Copilot (45 Seconds):
> *"Third, unlike public LLMs that hallucinate timestamps, TRACE-AI features a Zero-Hallucination Grounded AI Copilot. When an investigating officer asks 'What USB device was inserted?', the Copilot queries an immutable event graph and returns exact citations like [Log: EVT-002 @ 10:14:02 UTC]. Every claim is 100% mathematically and empirically verifiable."*

### 📜 Step 4: BSA 2023 / Section 65B Certificate (30 Seconds):
> *"Finally, TRACE-AI bridges the gap between technology and digital justice. Under Section 63 of Bharatiya Sakshya Adhiniyam 2023 (formerly Sec 65B), TRACE-AI generates a 1-click Electronic Evidence Certificate complete with master case hashes, system operating state declarations, and cryptographic legal seals—ready for submission in Indian courts of law."*

---

## 💻 4. Step-by-Step Live Product Walkthrough (How to Demonstrate)

Follow these steps during your live demo on `http://127.0.0.1:8000`:

| Step | Action on Screen | What to Say / Point Out |
|---|---|---|
| **1. Executive Dashboard** | Show top banner & incident metrics (`CRITICAL THREAT`, 5 correlated events, host `WORKSTATION-RIG-01`). | *"Here is our Executive Overview showing real-time threat scoring, host details, and triggered MITRE tactics."* |
| **2. Ingest Evidence** | Click **🔐 Ingest & SHA-256 Lock** tab. Show `sample_evidence.log` in the **Cryptographically Locked Evidence Files** table. | *"Here you see our evidence intake sandbox. Notice the SHA-256 hash `48a081076a...` logged instantly upon intake."* |
| **3. Swimlane Timeline** | Click **⏳ Swimlane Timeline** tab. Scroll through the chronological sequence. | *"Notice how events from 4 different log formats are microsecond-aligned into a single super timeline."* |
| **4. Causal Event Graph** | Click **🧠 Causal Event Graph** tab. Drag nodes around in the interactive Vis.js canvas. | *"This visual node-link graph links the Admin User to the USB insertion, the confidential file copy, and the outbound DNS beacon."* |
| **5. Grounded AI Copilot** | Click **🤖 Grounded AI Copilot** tab. Click prompt pill *"What USB device was inserted?"*. | *"Watch the Copilot answer in plain English while providing strict evidence citations `[Log: EVT-002]`."* |
| **6. Legal Certificate** | Click **📜 Sec 65B (BSA) Certificate** tab. Click **"Generate Certified Electronic Evidence Certificate"**. | *"Here is our Section 63 BSA 2023 court certificate complete with master case SHA-256 digest and Ed25519 legal seal."* |

---

## 🇮🇳 5. Strategic Impact & MeitY / ISEA Alignment

> [!TIP]
> **Why TRACE-AI Wins Hackathons**:
> - **Indigenous Cyber Defense**: Built specifically for Indian Law Enforcement Agencies (State Cyber Cells, CBI, Police Stations).
> - **Legal Compliance**: Direct alignment with **Bharatiya Sakshya Adhiniyam, 2023**.
> - **Reduces Backlog**: Empowers non-expert investigating officers to process complex forensic logs in minutes instead of weeks.

---

## 🖨️ 6. How to Save This Guide as PDF
You can export this document or the on-screen Section 65B Certificate as a PDF:
1. Open the Web Application at **[http://127.0.0.1:8000](http://127.0.0.1:8000)**.
2. Go to the **Sec 65B (BSA) Certificate** tab.
3. Click **🖨️ Print / Save Official PDF Certificate**.
4. In the print dialog, select **"Save as PDF"**!
